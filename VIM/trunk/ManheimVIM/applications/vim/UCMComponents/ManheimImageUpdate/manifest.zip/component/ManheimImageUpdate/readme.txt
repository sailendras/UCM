﻿ManheimImageUpdate Component

Overview:
Component resizes the image if checked in image resolution is higher than 800x600 on checkin.

Configuration :
1. ImageMagickCommandPath : Saves path or command name of Image Magick Convert command.




